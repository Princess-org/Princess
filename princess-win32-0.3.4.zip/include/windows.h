/*
%EXCLUDE WinMain wWinMain
*/
#ifdef _WIN32
    #include <Windows.h>
    #include <DbgHelp.h>
#endif