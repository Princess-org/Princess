// Include the whole standard library to generate ll files

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <math.h>
#include <assert.h>
#include <signal.h>
#include <stdarg.h>
#include <ctype.h>
#include <locale.h>
#include <setjmp.h>
#include <errno.h>
#include <float.h>
#include <limits.h>

#include "../princess.h"