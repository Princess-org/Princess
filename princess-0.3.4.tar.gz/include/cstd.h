/*
%EXCLUDE __acos __asin __atan __atan2 __cos __sin __tan __cosh __sinh __tanh __acosh __asinh __atanh __exp __frexp __ldexp __log __log10 __modf __expm1 __log1p __logb __exp2 __log2 __pow __sqrt __hypot __cbrt __ceil __fabs __floor __fmod __drem __significand __copysign __nan __j0 __j1 __jn __y0 __y1 __yn __erf __erfc __lgamma __tgamma __gamma __lgamma_r __rint __nextafter __nexttoward __remainder __scalbn __ilogb __scalbln __nearbyint __round __trunc __remquo __lrint __llrint __lround __llround __fdim __fmax __fmin __fma __scalb __acosf __asinf __atanf __atan2f __cosf __sinf __tanf __coshf __sinhf __tanhf __acoshf __asinhf __atanhf __expf __frexpf __ldexpf __logf __log10f __modff __expm1f __log1pf __logbf __exp2f __log2f __powf __sqrtf __hypotf __cbrtf __ceilf __fabsf __floorf __fmodf __dremf __significandf __copysignf __nanf __j0f __j1f __jnf __y0f __y1f __ynf __erff __erfcf __lgammaf __tgammaf __gammaf __lgammaf_r __rintf __nextafterf __nexttowardf __remainderf __scalbnf __ilogbf __scalblnf __nearbyintf __roundf __truncf __remquof __lrintf __llrintf __lroundf __llroundf __fdimf __fmaxf __fminf __fmaf __scalbf __acosl __asinl __atanl __atan2l __cosl __sinl __tanl __coshl __sinhl __tanhl __acoshl __asinhl __atanhl __expl __frexpl __ldexpl __logl __log10l __modfl __expm1l __log1pl __logbl __exp2l __log2l __powl __sqrtl __hypotl __cbrtl __ceill __fabsl __floorl __fmodl __dreml __significandl __copysignl __nanl __j0l __j1l __jnl __y0l __y1l __ynl __erfl __erfcl __lgammal __tgammal __gammal __lgammal_r __rintl __nextafterl __nexttowardl __remainderl __scalbnl __ilogbl __scalblnl __nearbyintl __roundl __truncl __remquol __lrintl __llrintl __lroundl __llroundl __fdiml __fmaxl __fminl __fmal __scalbl __builtin_va_start __builtin_va_end alloca tmpnam tmpnam_r tempnam sys_errlist sys_nerr mktemp sigstack sigreturn siggetmask sys_siglist _sys_siglist
%EXCLUDE __va_start _sopen_s_nolock
*/

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <math.h>
#include <assert.h>
#include <signal.h>
#include <stdarg.h>
#include <ctype.h>
#include <locale.h>
#include <setjmp.h>
#include <errno.h>
#include <float.h>
#include <limits.h>

#ifdef _WIN32
    #include <conio.h>
    #include <io.h>
#endif